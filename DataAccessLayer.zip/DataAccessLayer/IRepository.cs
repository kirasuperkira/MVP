﻿using System.Collections.Generic;
using Model;
using Dapper;


namespace DataAccessLayer
{

    public interface IRepository<T> where T : IDomainObject, new()
    {
        /// <summary>
        /// Создание обьекта
        /// </summary>
        /// <param name="obj">Добавляемый обьект</param>
        void Create(T obj);

        /// <summary>
        /// Обновление объекта
        /// </summary>
        /// <param name="obj">Обновляемый обьект</param>
        void Update(T obj);

        /// <summary>
        /// Удаление объекта по ID
        /// </summary>
        /// <param name="obj">Удаляемый обьект</param>
        void Delete(T obj);

        /// <summary>
        /// Считывание объектов
        /// </summary>
        /// <returns>Возвращение списка обьектов</returns>
        IEnumerable<T> ReadAll();

        /// <summary>
        /// Возвращение обьекта по ID
        /// </summary>
        /// <param name="id">ID объекта</param>
        /// <returns>Возвращение обьекта</returns>
        T ReadById(int id);
    }
}

