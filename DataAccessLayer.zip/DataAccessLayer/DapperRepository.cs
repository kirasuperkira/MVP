﻿
using Dapper;
using Model;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;


namespace DataAccessLayer
{
    public class DapperRepository : IRepository<Student>
    {
        private string connectionString;
        public DbSet<Student> Students { get; set; }

        public DapperRepository()
        {
            this.connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Кира\\source\\repos\\АИС\\lab 4\\DataAccessLayer\\Database2.mdf\";Integrated Security=True";
        }
        /// <summary>
        /// Выполнение запроса
        /// </summary>
        /// <param name="script">Строка запроса</param>
        private void UseScript(string script)
        {
            if (!string.IsNullOrEmpty(script))
            {
                using (IDbConnection db = new SqlConnection(connectionString))
                {
                    db.Execute(script);
                }
            }
        }

        /// <summary>
        /// Создание студента
        /// </summary>
        /// <param name="student"></param>
        public void Create(Student student)
        {
            string script = "INSERT INTO Students VALUES(N'" + student.Name + "', N'" + student.Speciality + "', N'" + student.Group + "')";
            UseScript(script);
        }

        /// <summary>
        /// Список студентов
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Student> ReadAll()
        {
            List<Student> students;
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                students = db.Query<Student>("SELECT * FROM Students").ToList();
            }
            return students;
        }

        /// <summary>
        /// Считывание по ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Student ReadById(int id)
        {
            Student student;
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                student = db.Query<Student>("SELECT * FROM Students WHERE Id =" + id).FirstOrDefault();
            }
            return student;
        }

        /// <summary>
        /// Изменение студента (обновление)
        /// </summary>
        /// <param name="student"></param>
        public void Update(Student student)
        {
            string script = "UPDATE Students SET [Name] = N'" + student.Name + "', [Group] = N'" + student.Group + "', [Speciality] = N'" + student.Speciality + "' WHERE Id = " + student.Id;
            UseScript(script);
        }

        /// <summary>
        /// Удаление студента
        /// </summary>
        /// <param name="student"></param>
        public void Delete(Student student)
        {
            string script = "DELETE FROM Students WHERE Id =" + student.Id;
            UseScript(script);
        }


    }
}
