﻿using Model;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;

namespace DataAccessLayer
{
    public class Context : DbContext
    {
        public Context() : base("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Кира\\source\\repos\\АИС\\lab 4\\DataAccessLayer\\Database2.mdf\";Integrated Security=True")
        { }
 public DbSet<Student> Students { get; set; }
    }

    public class EntityRepository : IRepository<Student>
    {

        public Context _context;
        public EntityRepository()
        {
            _context = new Context();
        }


        /// <summary>
        /// Создание студента
        /// </summary>
        /// <param name="student"></param>
        public void Create(Student student)
        {
            _context.Set<Student>().Add(student);
            _context.SaveChanges();
        }

        /// <summary>
        /// Список студентов
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Student> ReadAll()
        {
            return new List<Student>(_context.Set<Student>());
        }

        /// <summary>
        /// Считывание по ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Student ReadById(int id)
        {
            return _context.Set<Student>().Where(o => o.Id == id).FirstOrDefault();
        }

        /// <summary>
        /// Изменение студента
        /// </summary>
        /// <param name="student"></param>
        public void Update(Student student)
        {
            Student origin = _context.Set<Student>().Where(o => o.Id == student.Id).FirstOrDefault();
            origin.Name = student.Name;
            origin.Speciality = student.Speciality;
            origin.Group = student.Group;

            _context.SaveChanges();
        }

        /// <summary>
        /// Удаление студента
        /// </summary>
        /// <param name="student"></param>
        public void Delete(Student student)
        {var ToDelete = ReadById(student.Id);

            if (ToDelete != null)
            {

                _context.Set<Student>().Remove(student);
                _context.SaveChanges();
            }
        }

    }

}