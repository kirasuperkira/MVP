﻿using System;
using System.Collections.Generic;

namespace BusinessLogic
{
    public interface ILogic<T> where T : class
    {
        /// <summary>
        /// Событие запоминающее и передающее изменения через Presenter на View
        /// </summary>
        event Action<IEnumerable<T>> DataChanged;

        /// <summary>
        /// Создание объекта
        /// </summary>
        /// <param name="name"></param>
        /// <param name="speciality"></param>
        /// <param name="group"></param>
        void CreateStudent(string name, string speciality, string group);

        /// <summary>
        /// Удаление объекта по ID
        /// </summary>
        /// <param name="index"></param>
        void RemoveStudent(int index);

        /// <summary>
        /// Изменение данных об объекте
        /// </summary>
        /// <param name="name"></param>
        /// <param name="speciality"></param>
        /// <param name="group"></param>
        /// <param name="index"></param>
        void UpdateStudent(string name, string speciality, string group, int index);

        /// <summary>
        /// Список объектов
        /// </summary>
        /// <returns></returns>
        List<string[]> GetAllStudents();

        /// <summary>
        /// Словарь со специальностями и распределению объектов (количество студентов)
        /// </summary>
        /// <returns></returns>
        Dictionary<string, int> ShowGistogram();
    }
}
