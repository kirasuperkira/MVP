﻿using DataAccessLayer;
using Model;
using Ninject.Modules;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BusinessLogic
{
    public class SimpleConfigModule : NinjectModule
    {
        /// <summary>
        /// пПривязка Interface к конкретной реализации (по принципу Singleton)
        /// </summary>
        public override void Load()
        {
            Bind<IRepository<Student>>().To<EntityRepository>().InSingletonScope();
            //Bind<IRepository<Student>>().To<DapperRepository>().InSingletonScope();
            Bind<ILogic<Student>>().To<Logic>().InSingletonScope();
        }
    }

    public class Logic : ILogic<Student>
    {
        public IRepository<Student> Repository { set; get; }

        /// <summary>
        /// Событие запоминающее и передающее изменения через Presenter на View
        /// </summary>
        public event Action<IEnumerable<Student>> DataChanged;
        public Logic(IRepository<Student> repository)
        {
            Repository = repository;
        }

        /// <summary>
        /// Считывание данных
        /// </summary>
        private void InvokeDataChanged()
        {
            DataChanged?.Invoke(Repository.ReadAll());
        }

        /// <summary>
        /// Создание объекта
        /// </summary>
        /// <param name="name"></param>
        /// <param name="speciality"></param>
        /// <param name="group"></param>
        public void CreateStudent(string name, string speciality, string group)
        {
            Student student = new Student()
            {
                Name = name,
                Speciality = speciality,
                Group = group,
            };
            Repository.Create(student);
            InvokeDataChanged();
        }

        /// <summary>
        /// Удаление объекта по ID
        /// </summary>
        /// <param name="index"></param>
        public void RemoveStudent(int index)
        {
            Student student = Repository.ReadById(index);
            Repository.Delete(student);
            InvokeDataChanged();
        }

        /// <summary>
        /// Изменение данных об объекте
        /// </summary>
        /// <param name="name"></param>
        /// <param name="speciality"></param>
        /// <param name="group"></param>
        /// <param name="index"></param>
        public void UpdateStudent(string name, string speciality, string group, int index)
        {
            Student student = new Student()
            {
                Id = index,
                Name = name,
                Speciality = speciality,
                Group = group
                
            };
            Repository.Update(student);
            InvokeDataChanged();
        }

        /// <summary>
        /// Список объектов
        /// </summary>
        /// <returns></returns>
        public List<string[]> GetAllStudents()
        {
            List<string[]> Students = new List<string[]>();

            foreach (Student student in Repository.ReadAll())
            {
                string[] arraystudent = new string[4];
                arraystudent[0] = student.Id.ToString();
                arraystudent[1] = student.Name;
                arraystudent[2] = student.Speciality;
                arraystudent[3] = student.Group;

                Students.Add(arraystudent);

            }
            return Students;
        }

        /// <summary>
        /// Словарь со специальностями и распределению объектов (количество студентов)
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, int> ShowGistogram()
        {
            var Specialties = new Dictionary<string, int>();

            foreach (var student in Repository.ReadAll())
            {

                if (Specialties.ContainsKey(student.Speciality))
                {
                    Specialties[student.Speciality]++;
                }
                else
                {
                    Specialties[student.Speciality] = 1;
                }
            }
            var result = Specialties.OrderByDescending(x => x.Value).ToDictionary(x => x.Key, x => x.Value);
            return result;
        }
    }
}
