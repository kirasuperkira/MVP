﻿using System;
using System.Windows.Forms;
using _3_Практическая_работа_2;
using ConsoleApp2;

namespace _3_Практическая_работа_1
{
    public static class Starter
    {
        public static void StartConsole(ConsoleProgram program)
        {
            program.ConsoleView();
        }

        public static void StartForm(Form1 form)
        {
            Application.EnableVisualStyles();
            Application.Run(form);
        }
    }
}
