﻿
using Ninject;
using Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Forms;


namespace _3_Практическая_работа_2
{

    public partial class Form1 : Form, IView
    {
        public event Action<int> RemoveDataEvent;
        public event Action GetAllStudentsEvent;
        public event Action ShowGistogramEvent;
        public event Action<EventArgs> CreateDataEvent;
        public event Action<EventArgs> UpdateDataEvent;

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Добавление студента
        /// </summary>
        private void AddStudent(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text) & !string.IsNullOrEmpty(textBox2.Text) & !string.IsNullOrEmpty(textBox3.Text))
            {
                CreateDataEvent?.Invoke(new StudentModel() { Name = textBox1.Text, Speciality = textBox2.Text, Group = textBox3.Text });
                MessageBox.Show("Студент добавлен.");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            else MessageBox.Show("Некорректный ввод данных.");
        }

        /// <summary>
        /// Удаление студента
        /// </summary>
        private void RemoveStudent(object sender, EventArgs e)
        {
            if (TableStudents.SelectedItems.Count > 0)
            {
                ListViewItem f = TableStudents.SelectedItems[0];

                RemoveDataEvent?.Invoke(Int32.Parse(f.SubItems[0].Text));
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            else MessageBox.Show("Нажмите на строку студента в списке для его удаления.");
        }

        /// <summary>
        /// Получение списка студентов
        /// </summary>
        private void ShowStudents(object sender, EventArgs e)
        {
            GetAllStudentsEvent?.Invoke();
        }

        /// <summary>
        /// Получение гистограммы
        /// </summary>
        /// <param name="data"></param>
        public void HistogrammForm(Dictionary<string, int> data)
        {

            chart1.Series.Clear();
            var series = chart1.Series.Add("Распределение студентов по специальностям");

            Dictionary<string, int> Data_chart = data;

            var list = Data_chart.OrderByDescending(x => x.Value).Select(x => x.Key).ToList();
            var sortedValues = Data_chart.OrderByDescending(x => x.Value)
                        .Select(x => x.Value)
                        .ToList();

            for (int i = 0; i < Data_chart.Count; i++)
            {
                series.Points.Add(sortedValues[i]);
                series.Points[i].AxisLabel = list[i];
            }

        }
        /// <summary>
        /// Изменение студента
        /// </summary>
        private void ChangeStudent(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text) & !string.IsNullOrEmpty(textBox2.Text) & !string.IsNullOrEmpty(textBox3.Text))
            {
                ListViewItem studentSelect = TableStudents.SelectedItems[0]; //Обновление данных о студенте в файле (вызов функции)
                UpdateDataEvent?.Invoke(new StudentModel() { Id = Int32.Parse(studentSelect.SubItems[0].Text), Name = textBox1.Text, Speciality = textBox2.Text, Group = textBox3.Text });
                MessageBox.Show("Студент обновлен.");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            else MessageBox.Show("Некорректный ввод данных.");
        }

        /// <summary>
        /// Вывод гистограммы
        /// </summary>
        private void button5_Click(object sender, EventArgs e)
        {
            ShowGistogramEvent?.Invoke();
        }

        /// <summary>
        /// Вывод списка студентов
        /// </summary>
        public void RedrawForm(IEnumerable<EventArgs> data)
        {
            TableStudents.Items.Clear();

            foreach (StudentModel student in data)
            {
                string[] Student = new string[4];
                Student[0] = student.Id.ToString();
                Student[1] = student.Name;
                Student[3] = student.Group;
                Student[2] = student.Speciality;
                ListViewItem listViewItem = new ListViewItem();


                listViewItem.Text = $"{Student[0]}";
                listViewItem.SubItems.Add(Student[1]);
                listViewItem.SubItems.Add(Student[2]);
                listViewItem.SubItems.Add(Student[3]);

                TableStudents.Items.Add(listViewItem);
            }
        }

        /// <summary>
        /// Добавление данных в поля при выделении элемента списка
        /// </summary>
        private void TableStudents_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = TableStudents.SelectedItems[0].SubItems[1].Text;
            textBox2.Text = TableStudents.SelectedItems[0].SubItems[2].Text;
            textBox3.Text = TableStudents.SelectedItems[0].SubItems[3].Text;
        } 
    }

}