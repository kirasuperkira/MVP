﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using BusinessLogic;
using Model;
using Newtonsoft.Json;
using _3_Практическая_работа_1;
using CommunityToolkit.Mvvm;
using System.Net.Http.Headers;
using ConsoleTables;
using ClassLibrary1;
using Ninject;



namespace ConsoleApp1
{
    internal class Program
    {
        

        static void Main(string[] args)
        {
            IKernel ninjectKernel = new StandardKernel(new SimpleConfigModule());
            ILogic Logic = ninjectKernel.Get<ILogic>();
            Console.WriteLine("Добро пожаловать в Decanat Pro!");
            Console.WriteLine("Введите номер операции:\n1. Добавить нового студента\n2. Удалить сстудента\n3. Изменить студента\n" +
                              "4. Вывести весь список в таблицу\n5. Вывести гистограмму\n0. Выход из системы.");

            bool f = true;
            while (f)
            {
                Console.Write("\nНомер операции: ");
                int numberOperation = Convert.ToInt32(Console.ReadLine());
                switch (numberOperation)
                {
                    case 0:
                        {
                            f = false;
                            break;
                        }

                    case 1:
                        {
                            string[] dataStudent = new string[3];


                            Console.WriteLine("\nВведите через пробел ФИО студента: ");
                            dataStudent[0] = Console.ReadLine();
                            Console.WriteLine("\nВведите специальность студента: ");
                            dataStudent[1] = Console.ReadLine();
                            Console.WriteLine("\nВведите группу студента: ");
                            dataStudent[2] = Console.ReadLine();


                            Logic.CreateStudent(dataStudent[0], dataStudent[1], dataStudent[2]);
                            Console.WriteLine("Студент добавлен.");
                            Console.WriteLine("\nВведите номер операции:\n1. Добавить нового студента\n2. Удалить сстудента\n3. Изменить студента\n" +
                              "4. Вывести весь список в таблицу\n5. Вывести гистограмму\n0. Выход из системы.");
                            break;
                        }

                    case 2:
                        {
                            Console.WriteLine("\nВведите индекс студента, которого нужно удалить: ");
                            Logic.RemoveStudent(Int32.Parse(Console.ReadLine()));

                            Console.WriteLine("Студент удален.");
                            Console.WriteLine("\nВведите номер операции:\n1. Добавить нового студента\n2. Удалить сстудента\n3. Изменить студента\n" +
                              "4. Вывести весь список в таблицу\n5. Вывести гистограмму\n0. Выход из системы.");
                            break;
                        }

                    case 3:
                        {
                            string[] dataStudent = new string[4];

                            Console.WriteLine("\nВведите через пробел ФИО студента: ");
                            dataStudent[0] = Console.ReadLine();
                            Console.WriteLine("\nВведите специальность студента: ");
                            dataStudent[1] = Console.ReadLine();
                            Console.WriteLine("\nВведите группу студента: ");
                            dataStudent[2] = Console.ReadLine();
                            Console.WriteLine("\nВведите ID студента: ");
                            dataStudent[3] = Console.ReadLine();


                            Logic.UpdateStudent(dataStudent[0], dataStudent[1], dataStudent[2], Int32.Parse(dataStudent[3]));
                            Console.WriteLine("Студент изменен.");
                            break;
                        }

                    case 4:
                        {
                            var table = new ConsoleTable("ID", "ФИО", "Специальность", "Группа");
                            //список студентов
                            List<string[]> Students = Logic.GetAllStudents();
                            foreach (var s in Students)
                            {
                                table.AddRow(s[0], s[1], s[2], s[3]);
                            }
                            table.Write();
                            Console.WriteLine("\nВведите номер операции:\n1. Добавить нового студента\n2. Удалить сстудента\n3. Изменить студента\n" +
                              "4. Вывести весь список в таблицу\n5. Вывести гистограмму\n0. Выход из системы.");
                            break;

                        }

                    case 5:
                        {
                            Dictionary<string, int> DictionarySpecialites = Logic.GetSpecialties();

                            //создаю х и у для двойного массива, с помощью которого потом создам диаграмму
                            string[][] x = new string[DictionarySpecialites.Count][];
                            int maxValue = DictionarySpecialites.Values.Max(); //максимальное количество людей на какой либо спец

                            List<string> KeyFromDictionarySpecialites = new List<string>();

                            foreach (var key in DictionarySpecialites.Keys) //заполняю  массив специальностями 
                            {
                                KeyFromDictionarySpecialites.Add(key);

                            }

                            int k = 0;
                            foreach (var key in KeyFromDictionarySpecialites)
                            {
                                string[] y = new string[DictionarySpecialites[key] + 1];
                                y[0] = key;

                                for (int j = 1; j < DictionarySpecialites[key] + 1; j++) //заполняю высоту столбцов
                                {
                                    y[j] = "#";
                                }
                                x[k] = y;
                                k++;
                            }

                            Console.WriteLine();
                            Console.WriteLine("Специальность | Количество студентов на специальности");
                            Console.WriteLine("--------------|--------------------------------------");
                            foreach (var r in x)
                            {
                                Console.Write(r[0] + (String.Concat(Enumerable.Repeat(" ", 14 - r[0].Length))) + "|");
                                for (int i = 1; i < r.Length; i++)
                                {
                                    Console.Write(r[i]);
                                }
                                Console.Write(" " + $"{r.Length - 1}" + "\n");
                            }
                            Console.WriteLine("\nВведите номер операции:\n1. Добавить нового студента\n2. Удалить сстудента\n3. Изменить студента\n" +
                              "4. Вывести весь список в таблицу\n5. Вывести гистограмму\n0. Выход из системы.");
                            break;
                        }

                }
            }
        }
    }
}