﻿using BusinessLogic;
using ConsoleTables;
using System;
using System.Collections.Generic;
using System.Linq;
using Shared;
using System.Web.UI.WebControls;
using System.Security.Cryptography.X509Certificates;

namespace ConsoleApp2
{
    public class ConsoleProgram:IView
    {
        public event Action GetAllStudentsEvent;
        public event Action<int> RemoveDataEvent;
        public event Action ShowGistogramEvent;
        public event Action<EventArgs> CreateDataEvent;
        public event Action<EventArgs> UpdateDataEvent;

        public void RedrawForm(IEnumerable<EventArgs> data)
        {
            var table = new ConsoleTable("ID", "ФИО", "Специальность", "Группа");

            foreach (StudentModel s in data)
            {
                string[] Student = new string[4];

                Student[0] = s.Id.ToString();
                Student[1] = s.Name;
                Student[3] = s.Group;
                Student[2] = s.Speciality;

                table.AddRow(Student[0], Student[1], Student[2], Student[3]);
            }
            table.Write();
            Console.WriteLine("\nВведите номер операции:\n1. Добавить нового студента\n2. Удалить сстудента\n3. Изменить студента\n" +
                              "4. Вывести список студентов\n5. Вывести гистограмму (распределение по специальностям)");
        }

        /// <summary>
        /// Вывод гистограммы
        /// </summary>
        /// <param name="data"></param>
        public void HistogrammForm(Dictionary<string, int> data)
        {
            string[][] x = new string[data.Count][];
            int maxValue = data.Values.Max();

            List<string> KeyFromDictionarySpecialites = new List<string>();

            foreach (var key in data.Keys)
            {
                KeyFromDictionarySpecialites.Add(key);
            }

            int k = 0;
            foreach (var key in KeyFromDictionarySpecialites)
            {
                string[] y = new string[data[key] + 1];
                y[0] = key;

                for (int j = 1; j < data[key] + 1; j++)
                {
                    y[j] = "/";
                }
                x[k] = y;
                k++;
            }

            Console.WriteLine();
            Console.WriteLine("Специальность | Количество обучающихся студентов");
            Console.WriteLine("--------------|---------------------------------");
            foreach (var r in x)
            {
                Console.Write(r[0] + (String.Concat(Enumerable.Repeat(" ", 14 - r[0].Length))) + "|");
                for (int i = 1; i < r.Length; i++)
                {
                    Console.Write(r[i]);
                }
                Console.Write(" " + $"{r.Length - 1}" + "\n");
            }
        }
            /// <summary>
            /// Взаимодействие с консолью
            /// </summary>
            public void ConsoleView()
            {

                Console.WriteLine("Выберете действие:\n1. Добавить нового студента\n2. Удалить студента\n3. Изменить студента\n" +
                                  "4. Вывести список студентов\n5. Вывести гистограмму (распределение по специальностям)");

                
                while (true)
                {
                    Console.Write("\nНомер операции: ");
                    
                    var choice = Console.ReadKey().KeyChar;
                switch (choice)
                { 
                        case '1':
                            {
                                string[] dataStudent = new string[3];

                                Console.WriteLine("\nВведите ФИО студента: ");
                                dataStudent[0] = Console.ReadLine();
                                Console.WriteLine("\nВведите группу студента: ");
                                dataStudent[1] = Console.ReadLine();
                                Console.WriteLine("\nВведите специальность студента: ");
                                dataStudent[2] = Console.ReadLine();

                                Console.WriteLine("Студент добавлен.\n");

                                CreateDataEvent?.Invoke(new StudentModel() { Name = dataStudent[0], Speciality = dataStudent[1], Group = dataStudent[2] });
                                break;
                            }

                        case '2':
                            {
                                Console.WriteLine("\nВведите индекс студента, которого Вы хотите удалить: ");

                                RemoveDataEvent?.Invoke(Int32.Parse(Console.ReadLine()));

                                Console.WriteLine("Студент удален.");
                                break;
                            }

                        case '3':
                            {
                                string[] dataStudent = new string[4];
                                Console.WriteLine("\nВведите ID студента, которого Вы хотите изменить: ");
                                dataStudent[3] = Console.ReadLine();

                                Console.WriteLine("\nВведите ФИО студента: ");
                                dataStudent[0] = Console.ReadLine();
                                Console.WriteLine("\nВведите группу студента: ");
                                dataStudent[1] = Console.ReadLine();
                                Console.WriteLine("\nВведите специальность студента: ");
                                dataStudent[2] = Console.ReadLine();


                                UpdateDataEvent?.Invoke(new StudentModel() { Id = Int32.Parse(dataStudent[3]), Name = dataStudent[0], Speciality = dataStudent[1], Group = dataStudent[2] });
                                Console.WriteLine("Студент изменен.");
                                break;
                            }

                        case '4':
                            {
                                GetAllStudentsEvent?.Invoke();
                                break;
                            }

                        case '5':
                            {
                                ShowGistogramEvent?.Invoke();
                                break;
                            }
                    default: { break; }
                    }

                }

                Console.ReadKey();
            }
        static void Main(string[] args){}
    }
}